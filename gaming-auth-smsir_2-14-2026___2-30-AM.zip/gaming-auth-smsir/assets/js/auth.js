(function ($) {
  const state = {
    mobile: '',
    redirectTo: (window.gasAuth && window.gasAuth.redirectTo) || '/',
    usernameAvailable: false,
  };

  const messageEl = $('#gas-message');
  const usernameStatus = $('#gas-username-status');
  const signupBtn = $('#gas-complete-signup');

  const modal = $('#gas-modal');
  const openBtn = $('#gas-open-auth');

  const stepMeta = $('#gas-step-meta');
  const confirmMobile = $('#gas-confirm-mobile');

  const openModal = () => {
    if (!modal.length) return;
    modal.removeAttr('hidden');
    $('body').addClass('gas-modal-open');
  };

  const closeModal = () => {
    if (!modal.length) return;
    modal.attr('hidden', 'hidden');
    $('body').removeClass('gas-modal-open');
  };

  const goToStep = (stepName) => {
    $('.gas-step').removeClass('is-active');
    $(`[data-step="${stepName}"]`).addClass('is-active');

    if (stepName === 'mobile') {
      stepMeta.attr('hidden', 'hidden');
      return;
    }

    confirmMobile.text(state.mobile || '-');
    stepMeta.removeAttr('hidden');
  };

  const setMessage = (text, ok = false) => {
    const prefix = ok ? '✅ ' : '⚠️ ';
    messageEl
      .text(text ? `${prefix}${text}` : '')
      .toggleClass('is-ok', ok)
      .toggleClass('is-error', !ok)
      .toggleClass('has-message', Boolean(text));
  };

  const ajax = (action, payload) => {
    return $.post(window.gasAuth.ajaxUrl, {
      action,
      nonce: window.gasAuth.nonce,
      redirect_to: state.redirectTo,
      ...payload,
    });
  };

  openBtn.on('click', openModal);
  $(document).on('click', '[data-gas-close="1"]', closeModal);
  $(document).on('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  $('#gas-change-mobile').on('click', function () {
    goToStep('mobile');
    state.usernameAvailable = false;
    signupBtn.prop('disabled', true);
    usernameStatus.text('').removeClass('ok err');
    $('#gas-otp').val('');
    setMessage('');
  });

  $('#gas-send-otp').on('click', function () {
    state.mobile = $('#gas-mobile').val().trim();
    ajax('gas_send_otp', { mobile: state.mobile })
      .done((res) => {
        if (res.success) {
          setMessage(res.data.message, true);
          goToStep('otp');
        } else {
          setMessage(res.data.message || 'خطا در ارسال کد تایید');
        }
      })
      .fail((xhr) => setMessage(xhr.responseJSON?.data?.message || 'خطای شبکه'));
  });

  $('#gas-verify-otp').on('click', function () {
    const code = $('#gas-otp').val().trim();
    ajax('gas_verify_otp', { mobile: state.mobile, code })
      .done((res) => {
        if (!res.success) {
          return setMessage(res.data.message || 'خطا در تایید کد');
        }

        if (res.data.existing_user) {
          setMessage('ورود موفق. در حال انتقال...', true);
          window.location.href = res.data.redirect;
          return;
        }

        setMessage('شماره تایید شد. لطفاً نام کاربری انتخاب کنید.', true);
        goToStep('signup');
      })
      .fail((xhr) => setMessage(xhr.responseJSON?.data?.message || 'خطای شبکه'));
  });

  let usernameTimer;
  $('#gas-username').on('input', function () {
    const username = $(this).val().trim();
    clearTimeout(usernameTimer);
    usernameStatus.text('').removeClass('ok err');
    state.usernameAvailable = false;
    signupBtn.prop('disabled', true);

    if (username.length < 4) {
      return;
    }

    usernameTimer = setTimeout(() => {
      ajax('gas_check_username', { username })
        .done((res) => {
          if (res.success) {
            state.usernameAvailable = true;
            signupBtn.prop('disabled', false);
            usernameStatus.text(res.data.message).addClass('ok').removeClass('err');
          } else {
            usernameStatus.text(res.data.message).addClass('err').removeClass('ok');
          }
        })
        .fail((xhr) => {
          usernameStatus.text(xhr.responseJSON?.data?.message || 'خطا در بررسی نام کاربری').addClass('err').removeClass('ok');
        });
    }, 260);
  });

  $('#gas-complete-signup').on('click', function () {
    const username = $('#gas-username').val().trim();
    if (!state.usernameAvailable) {
      setMessage('ابتدا یک نام کاربری معتبر و آزاد انتخاب کنید.');
      return;
    }

    ajax('gas_complete_signup', { mobile: state.mobile, username })
      .done((res) => {
        if (res.success) {
          setMessage('ثبت‌نام با موفقیت انجام شد. در حال انتقال...', true);
          window.location.href = res.data.redirect;
        } else {
          setMessage(res.data.message || 'خطا در ثبت‌نام');
        }
      })
      .fail((xhr) => setMessage(xhr.responseJSON?.data?.message || 'خطای شبکه'));
  });

  goToStep('mobile');
})(jQuery);
